## ---- message=FALSE, eval=TRUE-------------------------------------------
library(ddiv)
data("IV_5M_1")
IVExtractResult(IV_5M_1)

data("IV_5M_2")
IVExtractResult(IV_5M_2)

