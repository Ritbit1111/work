## ---- message=FALSE, eval=TRUE-------------------------------------------
library(ddiv)
data("IV_daystar")
IVExtractResult(IV_daystar,k=4)

