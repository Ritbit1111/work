## ---- message=FALSE, eval=TRUE-------------------------------------------
library(ddiv)
data("IV_4K")
IVExtractResult(IV_4K)

